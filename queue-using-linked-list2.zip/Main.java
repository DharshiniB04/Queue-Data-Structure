import java.util.*;
public class Main
{
    static class node 
    {
        int data;
        node next;
        node(int d)
        {
            data=d;
            next=null;
        }
    }
    static node f=null,r=null;
    static void enq(int d)
    {
        node n=new node(d);
        if(isfull(n))
        {
        System.out.println("Heap overflow");
        return;
        }
        if(f==null)
        f=r=n;
        else
        {
            r.next=n;
            r=n;
        }
    }
    static boolean isfull(node n)
    {
        return n==null;
    }
    static void deq()
    {
        if(isempty())
        System.out.println("stack underflow");
        else
        f=f.next;
    }
    static boolean isempty()
    {
        return f==null;
    }
    static void dis()
    {
        node temp=f;
        while(temp!=null)
        {
            System.out.println(temp.data);
            temp=temp.next;
        }
    }
    static int peek()
    {
        return f.data;
    }
	public static void main(String[] args) {
	    Scanner s=new Scanner(System.in);
	    int b=1;
	    while(b!=0)
	    {
	    System.out.println("enter the choice \n 1-enq\n 2-deq\n 3-peek \n 4-dis \n 5-exit ");    
	    int c=s.nextInt();
	    switch(c)
	    {
	        case 1:
	            enq(s.nextInt());
	            break;
	        case 2:
	            deq();
	            break;
	        case 3:
	            System.out.println(peek());
	            break;
	        case 4:
	            dis();
	            break;
	        case 5:
	            b=0;
	    }
	    }
		
	}
}
