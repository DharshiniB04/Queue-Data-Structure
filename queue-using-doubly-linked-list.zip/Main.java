import java.util.*;
public class Main
{
    static class node 
    {
        int data;
        node next;
        node(int d)
        {
            data=d;
            next=null;
        }
    }
    static node f=null,r=null;
    static void enq(int d,int sd)
    {
        node n=new node(d);
        if(isfull(n))
        {
        System.out.println("Heap overflow");
        return;
        }
        if(f==null)
        f=r=n;
        else if(sd==1)
        {
            n.next=f;
            f=n;
        }
        else
        {
            r.next=n;
            r=n;
        }
    }
    static boolean isfull(node n)
    {
        return n==null;
    }
    static void deq(int de)
    {
        if(isempty())
        System.out.println("stack underflow");
        else if(de==1)
        f=f.next;
        else
        {
            node temp=f;
            node pre=null;
            while(temp.next!=null)
            {
              pre=temp;
              temp=temp.next;
            }
            pre.next=null;
        }
    }
    static boolean isempty()
    {
        return f==null;
    }
    static void dis()
    {
        node temp=f;
        while(temp!=null)
        {
            System.out.println(temp.data);
            temp=temp.next;
        }
    }
    static int peek()
    {
        return f.data;
    }
	public static void main(String[] args) {
	    Scanner s=new Scanner(System.in);
	    int b=1;
	    while(b!=0)
	    {
	    System.out.println("enter the choice \n 1-enq\n 2-deq\n 3-peek \n 4-dis \n 5-exit ");    
	    int c=s.nextInt();
	    switch(c)
	    {
	        case 1:
	            System.out.println("Insert the side \n 1-front else back");
	            int sd=s.nextInt();
	            enq(s.nextInt(),sd);
	            break;
	        case 2:
	            System.out.println("Delete the side \n 1-front else back");
	            int de=s.nextInt();
	            deq(de);
	            break;
	        case 3:
	            System.out.println(peek());
	            break;
	        case 4:
	            dis();
	            break;
	        case 5:
	            b=0;
	    }
	    }
		
	}
}
